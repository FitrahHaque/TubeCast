#!/usr/bin/env bash
set -e

IA_CONFIG="${HOME}/.config/internetarchive/ia.ini"
if [[ ! -f "${IA_CONFIG}" ]]; then
    echo "Internet Archive configuration not found: ${IA_CONFIG}"
    echo "Run ./ia configure before starting TubeCast."
    exit 1
fi

# Keep existing installations current, but allow the cached image to run offline.
docker compose pull --quiet tubecast || \
    echo "Could not check for updates; using the installed TubeCast image."

exec docker compose run --rm tubecast
